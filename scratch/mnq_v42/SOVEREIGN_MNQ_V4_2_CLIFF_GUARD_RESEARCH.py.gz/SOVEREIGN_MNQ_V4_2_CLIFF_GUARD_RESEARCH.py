from __future__ import annotations

"""
SOVEREIGN_MNQ_V4_2_CLIFF_GUARD_RESEARCH
=========================================
Research-only recovery-mode backtester built on frozen V3 signal logic.

Purpose:
- Keep V3's asymmetric 2.5R-4R exits.
- Size from remaining trailing-drawdown cushion instead of fixed aggression.
- Fail closed when cushion is too small.
- Preserve a cash reserve above the hard drawdown floor.
- Model a 50K Select-style $2,000 EOD trailing drawdown for research.

NO LIVE ORDERS. NOT VALIDATED FOR FUNDED DEPLOYMENT.
"""

import argparse, json, math
from pathlib import Path
import numpy as np
import pandas as pd

import SOVEREIGN_MNQ_V2_NO_PD_RESEARCH as base
import SOVEREIGN_MNQ_V3_BIG_R_GRADED_RESEARCH as v3

ET = base.ET
COST_1 = v3.COST_1
RESERVE_ABOVE_FLOOR = 350.0
HALT_CUSHION = 650.0


def recovery_tier(cushion: float, family: str, vol_ratio: float, trend_strength: float) -> dict:
    """Return fail-closed risk controls from current distance to hard floor."""
    if cushion < HALT_CUSHION:
        return {"name":"HALT", "max_qty":0, "trade_risk":0.0, "daily_stop":0.0, "max_trades":0}
    if cushion < 800:
        return {"name":"CLIFF_GUARD", "max_qty":1, "trade_risk":190.0, "daily_stop":190.0, "max_trades":1}
    if cushion < 1200:
        return {"name":"RECOVERY_1", "max_qty":2, "trade_risk":220.0, "daily_stop":260.0, "max_trades":2}
    if cushion < 1600:
        return {"name":"RECOVERY_2", "max_qty":2, "trade_risk":260.0, "daily_stop":320.0, "max_trades":2}
    setup_cap = v3.setup_cap(family, vol_ratio, trend_strength)
    return {
        "name":"NORMAL",
        "max_qty":setup_cap,
        "trade_risk":min(420.0, v3.RISK_BUDGET_BY_CAP.get(setup_cap, 420.0)),
        "daily_stop":420.0,
        "max_trades":3,
    }


def run_v4(
    x: pd.DataFrame,
    candidates: list[base.Candidate],
    cfg: base.Config,
    starting_balance: float,
    starting_floor: float,
    drawdown_amount: float,
) -> tuple[pd.DataFrame, dict]:
    rows = list(x.itertuples())
    start_ns = np.array([r.bar_start.value for r in rows], dtype=np.int64)
    trades = []
    next_free = pd.Timestamp("1900-01-01", tz=ET)

    balance = float(starting_balance)
    floor = float(starting_floor)
    high_water = max(float(starting_balance), float(starting_floor + drawdown_amount))
    daily_pnl: dict[str,float] = {}
    daily_n: dict[str,int] = {}
    current_sd = None
    day_open_balance = balance
    day_rows = []
    skipped_low_cushion = 0
    skipped_risk = 0

    def close_day(sd):
        nonlocal floor, high_water, day_open_balance
        if sd is None:
            return
        # EOD trailing floor only ratchets after the session has ended.
        if balance > high_water:
            high_water = balance
            floor = max(floor, high_water - drawdown_amount)
        day_rows.append({
            "session_date": str(sd),
            "start_balance": day_open_balance,
            "end_balance": balance,
            "net": balance-day_open_balance,
            "floor_after_eod": floor,
            "cushion_after_eod": balance-floor,
        })
        day_open_balance = balance

    for c in sorted(candidates, key=lambda z: z.signal_time):
        sd = base.trading_session_date(c.signal_time)
        if current_sd is None:
            current_sd = sd
        elif sd != current_sd:
            close_day(current_sd)
            current_sd = sd

        if c.signal_time < next_free:
            continue

        cushion = balance - floor
        # Need signal-row context before tiering normal mode.
        sig = x.loc[x.bar_end == c.signal_time]
        if sig.empty:
            vr, ts = 1.0, 0.0
        else:
            rr = sig.iloc[-1]
            vr = float(rr.vol_ratio) if np.isfinite(rr.vol_ratio) else 1.0
            ts = float(rr.trend_strength) if np.isfinite(rr.trend_strength) else 0.0
        tier = recovery_tier(cushion, c.family, vr, ts)
        if tier["max_qty"] <= 0:
            skipped_low_cushion += 1
            continue
        if daily_n.get(str(sd),0) >= tier["max_trades"]:
            continue
        if daily_pnl.get(str(sd),0.0) <= -tier["daily_stop"]:
            continue

        k = int(np.searchsorted(start_ns, c.signal_time.value, side="left"))
        if k >= len(rows):
            continue
        er = rows[k]
        if base.trading_session_date(er.bar_start) != sd:
            continue
        entry = float(er.open)
        atr = float(c.atr)
        stop, risk = v3.family_stop(x, c, entry, atr, cfg)
        if not np.isfinite(risk) or risk <= 0 or risk < cfg.min_stop_atr*atr or risk > cfg.max_stop_atr*atr:
            continue

        per_contract_stop = risk*base.MNQ_POINT_VALUE + COST_1
        usable_cushion = max(0.0, cushion - RESERVE_ABOVE_FLOOR)
        # Never allocate more than half of cushion remaining after the reserve.
        risk_fraction = 0.65 if tier["name"] == "CLIFF_GUARD" else 0.50
        risk_budget = min(tier["trade_risk"], risk_fraction*usable_cushion)
        qty = min(int(tier["max_qty"]), int(risk_budget // per_contract_stop))
        if qty < 1:
            skipped_risk += 1
            continue

        target_r = v3.TARGET_R[c.family]
        target = entry + c.direction*target_r*risk
        exit_price = None; exit_time = None; reason = None
        for j in range(k, len(rows)):
            r = rows[j]
            if base.trading_session_date(r.bar_start) != sd:
                exit_price = float(rows[j-1].close) if j > k else entry
                exit_time = rows[j-1].bar_end if j > k else er.bar_end
                reason = "session_boundary"; break
            if r.bar_start.tz_convert(ET).time() >= pd.Timestamp(cfg.eod_exit_et).time():
                exit_price = float(r.open); exit_time = r.bar_start; reason = "eod"; break
            h, l = float(r.high), float(r.low)
            if c.direction > 0:
                if l <= stop:
                    exit_price = stop; exit_time = r.bar_end; reason = "stop"; break
                if h >= target:
                    exit_price = target; exit_time = r.bar_end; reason = "target"; break
            else:
                if h >= stop:
                    exit_price = stop; exit_time = r.bar_end; reason = "stop"; break
                if l <= target:
                    exit_price = target; exit_time = r.bar_end; reason = "target"; break
        if exit_price is None:
            exit_price = float(rows[-1].close); exit_time = rows[-1].bar_end; reason = "data_end"

        gross_pts = c.direction*(float(exit_price)-entry)
        net1 = gross_pts*base.MNQ_POINT_VALUE - COST_1
        scaled = net1*qty
        pre_balance = balance
        balance += scaled
        post_cushion = balance-floor
        planned_stop_dollars = per_contract_stop*qty

        trades.append({
            "family":c.family,
            "direction":"LONG" if c.direction>0 else "SHORT",
            "signal_time":c.signal_time,
            "entry_time":er.bar_start,
            "exit_time":exit_time,
            "entry":entry,"stop":stop,"target":target,"exit_price":float(exit_price),
            "exit_reason":reason,"risk_points":risk,"target_r":target_r,
            "vol_ratio":vr,"trend_strength":ts,
            "tier":tier["name"],"quantity":qty,
            "planned_stop_dollars":planned_stop_dollars,
            "net_1mnq":net1,"net_recovery":scaled,
            "balance_before":pre_balance,"balance_after":balance,
            "floor":floor,"cushion_before":cushion,"cushion_after":post_cushion,
            "session_date":str(sd),"context":c.context,
        })
        daily_n[str(sd)] = daily_n.get(str(sd),0)+1
        daily_pnl[str(sd)] = daily_pnl.get(str(sd),0.0)+scaled
        next_free = exit_time

        # Hard fail-closed invariant for the simulator. A real executor must use broker
        # net-liq and current dashboard floor continuously, not just closed PnL.
        if balance <= floor:
            break

    close_day(current_sd)
    t = pd.DataFrame(trades)
    state = {
        "starting_balance":starting_balance,
        "starting_floor":starting_floor,
        "starting_cushion":starting_balance-starting_floor,
        "ending_balance":balance,
        "ending_floor":floor,
        "ending_cushion":balance-floor,
        "high_water":high_water,
        "drawdown_amount":drawdown_amount,
        "reserve_above_floor":RESERVE_ABOVE_FLOOR,
        "halt_cushion":HALT_CUSHION,
        "skipped_low_cushion":skipped_low_cushion,
        "skipped_risk":skipped_risk,
        "days":day_rows,
    }
    return t, state


def metrics(p: pd.Series) -> dict:
    if len(p)==0:
        return {"trades":0,"wins":0,"win_rate":0.0,"net":0.0,"profit_factor":0.0,"max_drawdown":0.0}
    p=p.astype(float); wins=int((p>0).sum()); w=p[p>0].sum(); l=-p[p<0].sum()
    eq=pd.concat([pd.Series([0.0]),p.cumsum().reset_index(drop=True)],ignore_index=True)
    return {
        "trades":int(len(p)),"wins":wins,"win_rate":100*wins/len(p),"net":float(p.sum()),
        "profit_factor":float(w/l) if l>0 else float("inf"),
        "max_drawdown":float((eq.cummax()-eq).max()),
    }


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("csv",type=Path)
    ap.add_argument("--source-tz",default="UTC")
    ap.add_argument("--input-minutes",type=int,choices=[1,5],default=5)
    ap.add_argument("--starting-balance",type=float,required=True)
    ap.add_argument("--drawdown-floor",type=float,required=True)
    ap.add_argument("--drawdown-amount",type=float,default=2000.0)
    ap.add_argument("--out",type=Path,default=Path("MNQ_V4_RECOVERY_RESULTS"))
    args=ap.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    cfg=base.Config()
    x=base.load_bars(args.csv,args.source_tz,args.input_minutes)
    x,_=base.add_features(x,cfg); x=base.add_session_levels(x); x=v3.add_v3_features(x)
    z=v3.base.detect_zones(x,"5m",cfg); c=v3.generate_v3_candidates(x,z,cfg)
    t,state=run_v4(x,c,cfg,args.starting_balance,args.drawdown_floor,args.drawdown_amount)
    report={
        "engine":"SOVEREIGN_MNQ_V4_2_CLIFF_GUARD_RESEARCH",
        "orders_enabled":False,
        "bars_5m":len(x),"candidate_count":len(c),
        "performance":metrics(t.net_recovery if len(t) else pd.Series(dtype=float)),
        "normalized_1mnq":metrics(t.net_1mnq if len(t) else pd.Series(dtype=float)),
        "state":state,
        "disclosure":"Research only. Starting floor must be the exact current Tradeify dashboard trailing-drawdown floor. Closed-bar research cannot guarantee intraday net-liq safety or profitability."
    }
    t.to_csv(args.out/"trades.csv",index=False)
    pd.DataFrame(state["days"]).to_csv(args.out/"days.csv",index=False)
    (args.out/"report.json").write_text(json.dumps(report,indent=2,default=str))
    print(json.dumps(report,indent=2,default=str))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
