from __future__ import annotations

"""
SOVEREIGN_MNQ_V3_BIG_R_GRADED_RESEARCH
======================================
Research-only MNQ backtester. Sends no orders.

V3 changes versus V2:
- Adds DISPLACEMENT_PULLBACK and ORB_RETEST_CONTINUATION specialists.
- Uses family-specific structural stops and 2.5R-4.0R targets.
- Grades position size 2/4/6 MNQ, but actual quantity is also capped by the
  dollar risk implied by the structural stop.
- Applies a $520 scaled daily self-stop and maximum four trades/session.
- Keeps 1-MNQ normalized PnL beside scaled PnL so sizing cannot hide a bad edge.

This file depends on SOVEREIGN_MNQ_V2_NO_PD_RESEARCH.py in the same directory.
Historical research only; no live orders.
"""

import argparse, json, math
from dataclasses import asdict
from pathlib import Path
import numpy as np
import pandas as pd

import SOVEREIGN_MNQ_V2_NO_PD_RESEARCH as base

ET = base.ET
COST_1 = 3.28  # matches base commission + one adverse tick each side

TARGET_R = {
    "SWEEP_FVG_REVERSAL": 2.5,
    "TREND_FVG_CONTINUATION": 3.0,
    "ORB_RETEST_CONTINUATION": 3.5,
    "DISPLACEMENT_PULLBACK": 4.0,
}

RISK_BUDGET_BY_CAP = {2: 220.0, 4: 420.0, 6: 520.0}
DAILY_SCALED_STOP = 520.0
MAX_TRADES_PER_DAY = 4


def add_v3_features(x: pd.DataFrame) -> pd.DataFrame:
    y = x.copy()
    y["vol_med20"] = y.volume.rolling(20, min_periods=10).median()
    y["vol_ratio"] = y.volume / y.vol_med20.replace(0, np.nan)
    y["trend_strength"] = (y.ema_fast-y.ema_slow).abs() / y.atr15.replace(0, np.nan)
    return y


def generate_v3_candidates(x: pd.DataFrame, zones5: list[base.Zone], cfg: base.Config) -> list[base.Candidate]:
    out = list(base.generate_candidates(x, zones5, cfg))
    rows = list(x.itertuples())

    # Specialist 1: 30-minute opening-range breakout followed by a pullback/reclaim.
    # OR levels are complete before this specialist is allowed to start at 10:00 ET.
    for i, r in enumerate(rows):
        dt = r.bar_end
        t = dt.tz_convert(ET).time()
        if not (pd.Timestamp("10:00").time() <= t <= pd.Timestamp("12:30").time()):
            continue
        if not np.isfinite(r.atr) or not np.isfinite(r.or_high) or not np.isfinite(r.or_low):
            continue
        trend_up = np.isfinite(r.ema_fast) and r.ema_fast > r.ema_slow and r.slow_slope > 0
        trend_dn = np.isfinite(r.ema_fast) and r.ema_fast < r.ema_slow and r.slow_slope < 0
        prev = rows[max(0, i-6):i]
        broke_up = any(p.close > r.or_high + 0.05*r.atr for p in prev)
        broke_dn = any(p.close < r.or_low - 0.05*r.atr for p in prev)
        if trend_up and broke_up and r.low <= r.or_high + 0.10*r.atr and r.close > r.or_high and r.close > r.open and r.close_loc >= .60:
            out.append(base.Candidate("ORB_RETEST_CONTINUATION", +1, dt, -100000-i,
                                      r.or_high-0.10*r.atr, r.or_high+0.05*r.atr,
                                      float(r.atr), f"orh={r.or_high:.2f}"))
        if trend_dn and broke_dn and r.high >= r.or_low - 0.10*r.atr and r.close < r.or_low and r.close < r.open and r.close_loc <= .40:
            out.append(base.Candidate("ORB_RETEST_CONTINUATION", -1, dt, -200000-i,
                                      r.or_low-0.05*r.atr, r.or_low+0.10*r.atr,
                                      float(r.atr), f"orl={r.or_low:.2f}"))

    # Specialist 2: strong displacement, then a controlled 30%-70% retrace and rejection.
    for i, r in enumerate(rows):
        dt = r.bar_end
        t = dt.tz_convert(ET).time()
        if not (pd.Timestamp("09:35").time() <= t <= pd.Timestamp("12:30").time()):
            continue
        if not np.isfinite(r.atr):
            continue
        trend_up = np.isfinite(r.ema_fast) and r.ema_fast > r.ema_slow and r.slow_slope > 0
        trend_dn = np.isfinite(r.ema_fast) and r.ema_fast < r.ema_slow and r.slow_slope < 0
        for lag in range(1, 7):
            j = i-lag
            if j < 0:
                break
            d = rows[j]
            if not np.isfinite(d.atr) or d.range < 1.15*d.atr or d.body_ratio < .60:
                continue
            if d.close > d.open and d.close_loc >= .78 and trend_up:
                impulse = d.close-d.open
                retr_hi = d.close - .30*impulse
                retr_lo = d.close - .70*impulse
                if r.low <= retr_hi and r.low >= min(d.low, retr_lo)-.15*r.atr and r.close > retr_hi and r.close > r.open and r.close_loc >= .58:
                    out.append(base.Candidate("DISPLACEMENT_PULLBACK", +1, dt, -300000-i*10-lag,
                                              min(d.low, retr_lo), retr_hi, float(r.atr), f"lag={lag}"))
                    break
            if d.close < d.open and d.close_loc <= .22 and trend_dn:
                impulse = d.open-d.close
                retr_lo = d.close + .30*impulse
                retr_hi = d.close + .70*impulse
                if r.high >= retr_lo and r.high <= max(d.high, retr_hi)+.15*r.atr and r.close < retr_lo and r.close < r.open and r.close_loc <= .42:
                    out.append(base.Candidate("DISPLACEMENT_PULLBACK", -1, dt, -400000-i*10-lag,
                                              retr_lo, max(d.high, retr_hi), float(r.atr), f"lag={lag}"))
                    break

    # Deterministic de-duplication.
    dedup, seen = [], set()
    for c in sorted(out, key=lambda z: (z.signal_time, z.family, z.direction)):
        key = (c.family, c.direction, c.signal_time)
        if key not in seen:
            seen.add(key); dedup.append(c)
    return dedup


def setup_cap(family: str, vol_ratio: float, trend_strength: float) -> int:
    # Six contracts are reserved for the two higher-R specialists. Base FVG/sweep
    # families can never jump straight to six on one noisy high-volume bar.
    if family in {"DISPLACEMENT_PULLBACK", "ORB_RETEST_CONTINUATION"}:
        if vol_ratio >= 1.25 and trend_strength >= .10:
            return 6
        if trend_strength >= .07:
            return 4
        return 2
    if vol_ratio >= 1.25 and trend_strength >= .10:
        return 4
    return 2


def family_stop(x: pd.DataFrame, c: base.Candidate, entry: float, atr: float, cfg: base.Config) -> tuple[float, float]:
    buf = cfg.zone_buffer_atr * atr
    if c.direction > 0:
        stop = c.zone_lower - buf
        risk = entry-stop
    else:
        stop = c.zone_upper + buf
        risk = stop-entry

    # Higher-R specialists use the confirmation/rejection candle as structural
    # invalidation. This candle is fully complete at c.signal_time.
    if c.family in {"DISPLACEMENT_PULLBACK", "ORB_RETEST_CONTINUATION"}:
        hit = x.loc[x.bar_end == c.signal_time]
        if hit.empty:
            return stop, risk
        b = hit.iloc[-1]
        if c.direction > 0:
            stop = min(entry-.25*atr, float(b.low)-buf)
            risk = entry-stop
        else:
            stop = max(entry+.25*atr, float(b.high)+buf)
            risk = stop-entry
    return float(stop), float(risk)


def run_v3(x: pd.DataFrame, candidates: list[base.Candidate], cfg: base.Config) -> pd.DataFrame:
    rows = list(x.itertuples())
    start_ns = np.array([r.bar_start.value for r in rows], dtype=np.int64)
    trades = []
    next_free = pd.Timestamp("1900-01-01", tz=ET)
    daily_scaled = {}
    daily_n = {}

    for c in sorted(candidates, key=lambda z: z.signal_time):
        sd = base.trading_session_date(c.signal_time)
        if daily_n.get(sd, 0) >= MAX_TRADES_PER_DAY or daily_scaled.get(sd, 0.0) <= -DAILY_SCALED_STOP:
            continue
        if c.signal_time < next_free:
            continue
        k = int(np.searchsorted(start_ns, c.signal_time.value, side="left"))
        if k >= len(rows):
            continue
        er = rows[k]
        if base.trading_session_date(er.bar_start) != sd:
            continue
        entry = float(er.open)
        atr = float(c.atr)
        stop, risk = family_stop(x, c, entry, atr, cfg)
        if not np.isfinite(risk) or risk <= 0 or risk < cfg.min_stop_atr*atr or risk > cfg.max_stop_atr*atr:
            continue

        target_r = TARGET_R[c.family]
        target = entry + c.direction*target_r*risk
        sig = x.loc[x.bar_end == c.signal_time]
        if sig.empty:
            vr, ts = 1.0, 0.0
        else:
            rr = sig.iloc[-1]
            vr = float(rr.vol_ratio) if np.isfinite(rr.vol_ratio) else 1.0
            ts = float(rr.trend_strength) if np.isfinite(rr.trend_strength) else 0.0
        cap = setup_cap(c.family, vr, ts)
        per_contract_stop_loss = risk*base.MNQ_POINT_VALUE + COST_1
        budget = RISK_BUDGET_BY_CAP[cap]
        qty = max(1, min(cap, int(budget // per_contract_stop_loss)))

        exit_price = None; exit_time = None; reason = None
        for j in range(k, len(rows)):
            r = rows[j]
            if base.trading_session_date(r.bar_start) != sd:
                exit_price = float(rows[j-1].close) if j > k else entry
                exit_time = rows[j-1].bar_end if j > k else er.bar_end
                reason = "session_boundary"; break
            if r.bar_start.tz_convert(ET).time() >= pd.Timestamp(cfg.eod_exit_et).time():
                exit_price = float(r.open); exit_time = r.bar_start; reason = "eod"; break
            h, l = float(r.high), float(r.low)
            # Conservative stop-first ordering when both levels occur in one 5m bar.
            if c.direction > 0:
                if l <= stop:
                    exit_price = stop; exit_time = r.bar_end; reason = "stop"; break
                if h >= target:
                    exit_price = target; exit_time = r.bar_end; reason = "target"; break
            else:
                if h >= stop:
                    exit_price = stop; exit_time = r.bar_end; reason = "stop"; break
                if l <= target:
                    exit_price = target; exit_time = r.bar_end; reason = "target"; break
        if exit_price is None:
            exit_price = float(rows[-1].close); exit_time = rows[-1].bar_end; reason = "data_end"

        gross_pts = c.direction*(float(exit_price)-entry)
        net1 = gross_pts*base.MNQ_POINT_VALUE - COST_1
        net2 = net1*2; net4 = net1*4; net6 = net1*6
        scaled = net1*qty
        net_r = net1 / max(risk*base.MNQ_POINT_VALUE + COST_1, 1e-9)
        trades.append({
            "family": c.family,
            "direction": "LONG" if c.direction > 0 else "SHORT",
            "signal_time": c.signal_time,
            "entry_time": er.bar_start,
            "exit_time": exit_time,
            "entry": entry, "stop": stop, "target": target, "exit_price": float(exit_price),
            "exit_reason": reason, "risk_points": risk, "target_r": target_r,
            "vol_ratio": vr, "trend_strength": ts, "grade_cap": cap, "quantity": qty,
            "net_1mnq": net1, "net_2mnq": net2, "net_4mnq": net4, "net_6mnq": net6,
            "net_graded": scaled, "net_r": net_r, "session_date": str(sd), "context": c.context,
        })
        daily_n[sd] = daily_n.get(sd, 0)+1
        daily_scaled[sd] = daily_scaled.get(sd, 0.0)+scaled
        next_free = exit_time
    return pd.DataFrame(trades)


def metric(series: pd.Series) -> dict:
    if len(series) == 0:
        return {"net":0.0,"profit_factor":0.0,"max_drawdown":0.0}
    p = series.astype(float)
    w = p[p>0].sum(); l = -p[p<0].sum()
    eq = pd.concat([pd.Series([0.0]), p.cumsum().reset_index(drop=True)], ignore_index=True)
    dd = eq.cummax()-eq
    return {"net":float(p.sum()), "profit_factor":float(w/l) if l>0 else float("inf"), "max_drawdown":float(dd.max())}


def build_report(x: pd.DataFrame, cands: list[base.Candidate], trades: pd.DataFrame, cfg: base.Config) -> dict:
    sessions = base.complete_session_dates(x, cfg)
    out = {
        "engine":"SOVEREIGN_MNQ_V3_BIG_R_GRADED_RESEARCH",
        "orders_enabled":False,
        "bars_5m":len(x), "sessions":len(sessions), "candidates":len(cands), "trades":len(trades),
        "trades_per_session": float(len(trades)/len(sessions)) if sessions else 0.0,
        "win_rate": float((trades.net_1mnq>0).mean()*100) if len(trades) else 0.0,
        "normalized_1mnq": metric(trades.net_1mnq if len(trades) else pd.Series(dtype=float)),
        "fixed_2mnq": metric(trades.net_2mnq if len(trades) else pd.Series(dtype=float)),
        "fixed_4mnq": metric(trades.net_4mnq if len(trades) else pd.Series(dtype=float)),
        "fixed_6mnq": metric(trades.net_6mnq if len(trades) else pd.Series(dtype=float)),
        "graded_sizing": metric(trades.net_graded if len(trades) else pd.Series(dtype=float)),
        "best_trade_1mnq": float(trades.net_1mnq.max()) if len(trades) else 0.0,
        "best_trade_graded": float(trades.net_graded.max()) if len(trades) else 0.0,
        "worst_trade_graded": float(trades.net_graded.min()) if len(trades) else 0.0,
        "by_family": {}, "by_day": {},
        "sizing":{"caps":[2,4,6],"risk_budget_by_cap":RISK_BUDGET_BY_CAP,"daily_scaled_stop":DAILY_SCALED_STOP},
        "target_r":TARGET_R,
        "disclosure":"Development research, not validated for live/funded trading. Contract scaling multiplies both gains and losses. 5m ambiguous bars use stop-first handling."
    }
    if len(trades):
        for f,g in trades.groupby("family"):
            out["by_family"][f] = {"trades":len(g),"win_rate":float((g.net_1mnq>0).mean()*100),"net_1mnq":float(g.net_1mnq.sum()),"net_graded":float(g.net_graded.sum())}
        for d,g in trades.groupby("session_date"):
            out["by_day"][d] = {"trades":len(g),"net_1mnq":float(g.net_1mnq.sum()),"net_graded":float(g.net_graded.sum())}
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", type=Path)
    ap.add_argument("--source-tz", default="UTC")
    ap.add_argument("--input-minutes", type=int, choices=[1,5], default=5)
    ap.add_argument("--out", type=Path, default=Path("MNQ_V3_RESULTS"))
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    cfg = base.Config()
    x = base.load_bars(args.csv, args.source_tz, args.input_minutes)
    x, df15 = base.add_features(x, cfg)
    x = base.add_session_levels(x)
    x = add_v3_features(x)
    zones5 = base.detect_zones(x, "5m", cfg)
    cands = generate_v3_candidates(x, zones5, cfg)
    trades = run_v3(x, cands, cfg)
    report = build_report(x, cands, trades, cfg)
    trades.to_csv(args.out/"trades.csv", index=False)
    pd.DataFrame([asdict(c) for c in cands]).to_csv(args.out/"candidates.csv", index=False)
    (args.out/"report.json").write_text(json.dumps(report, indent=2, default=str))
    print(json.dumps(report, indent=2, default=str))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
