from __future__ import annotations

"""
SOVEREIGN_MNQ_V2_NO_PD_RESEARCH
=========================
Causal NQ/MNQ research backtester. Research only: sends no orders.

Core design goals:
- Stateful FVG zones: once mitigated/invalidated, a zone can never resurrect.
- Completed-bar causality: a 3-candle FVG becomes known only after candle 3 closes.
- Two independent setup families:
    1) SWEEP_FVG_REVERSAL: overnight liquidity sweep/reclaim -> FVG -> retest/rejection.
    2) TREND_FVG_CONTINUATION: 15m trend + 5m FVG -> retest/rejection.
- Both directions are generated and reported separately.
- Next-bar-open entries, one position at a time, stop-first handling for ambiguous bars.
- Explicit MNQ economics and friction assumptions.
- Fixed parameters by default. No automatic optimization against later years.

Input CSV:
  Required: datetime/timestamp, open, high, low, close, volume (volume optional)
  1-minute or 5-minute input supported. One-minute input is aggregated to 5-minute bars.
  Timestamps are interpreted in --source-tz and represent BAR START times by default.

Example:
  python SOVEREIGN_MNQ_V2_NO_PD_RESEARCH.py NQ_1min_2022_2025.csv --source-tz America/New_York
"""

import argparse
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional, Iterable
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

ET = ZoneInfo("America/New_York")

MNQ_POINT_VALUE = 2.0
MNQ_TICK_SIZE = 0.25
MNQ_TICK_VALUE = 0.50


@dataclass(frozen=True)
class Config:
    # Conservative friction model: $2.28 modeled roundturn fees + one adverse tick each side.
    commission_roundturn: float = 2.28
    slippage_ticks_each_side: int = 1

    atr_period: int = 14
    fvg_min_atr: float = 0.10
    fvg_min_points: float = 1.00
    fvg_max_age_bars_5m: int = 36       # 3 hours
    fvg_invalidate_at_midpoint: bool = True
    zone_buffer_atr: float = 0.08
    min_stop_atr: float = 0.20
    max_stop_atr: float = 2.50

    sweep_lookback_bars: int = 12       # 60m after sweep
    sweep_reclaim_atr: float = 0.03
    sweep_target_r: float = 2.00

    trend_fast_15m: int = 8
    trend_slow_15m: int = 21
    trend_slope_lookback: int = 3
    trend_target_r: float = 2.50
    trend_pd_tolerance: float = 0.10    # ATR tolerance around ON midpoint

    entry_start_et: str = "09:35"
    entry_end_et: str = "12:30"
    eod_exit_et: str = "15:45"
    max_trades_per_day: int = 3
    daily_stop_r: float = 2.0

    # Research sizing only. Fixed one-MNQ ledger is primary; this budget produces an
    # additional risk-normalized quantity view and is never used to select signals.
    risk_budget_dollars: float = 100.0
    max_mnq_contracts: int = 10


@dataclass
class Zone:
    zid: int
    timeframe: str
    direction: int                 # +1 bull, -1 bear
    born_time: pd.Timestamp        # timestamp when pattern is fully KNOWN
    lower: float
    upper: float
    midpoint: float
    impulse_index: int
    dead_time: Optional[pd.Timestamp] = None
    death_reason: Optional[str] = None

    def alive_at(self, ts: pd.Timestamp) -> bool:
        return self.born_time <= ts and (self.dead_time is None or ts < self.dead_time)


@dataclass
class Candidate:
    family: str
    direction: int
    signal_time: pd.Timestamp
    zone_id: int
    zone_lower: float
    zone_upper: float
    atr: float
    context: str


@dataclass
class Trade:
    family: str
    direction: str
    signal_time: pd.Timestamp
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp
    entry: float
    stop: float
    target: float
    exit_price: float
    exit_reason: str
    risk_points: float
    gross_points: float
    gross_dollars_1mnq: float
    costs_1mnq: float
    net_dollars_1mnq: float
    net_r: float
    quantity_risk_budget: int
    net_dollars_risk_budget: float
    session_date: str
    zone_id: int
    context: str


def _col(df: pd.DataFrame, names: Iterable[str]) -> Optional[str]:
    lookup = {str(c).strip().lower(): c for c in df.columns}
    for n in names:
        if n.lower() in lookup:
            return lookup[n.lower()]
    return None


def load_bars(path: Path, source_tz: str, input_minutes: int | None = None) -> pd.DataFrame:
    df = pd.read_csv(path)
    tcol = _col(df, ["datetime", "timestamp", "timestamp et", "date", "time"])
    if tcol is None:
        raise ValueError("Could not find datetime/timestamp column")
    mapping = {}
    for canonical, aliases in {
        "open": ["open", "o"], "high": ["high", "h"], "low": ["low", "l"],
        "close": ["close", "c", "last"], "volume": ["volume", "vol", "v"],
    }.items():
        c = _col(df, aliases)
        if c is not None:
            mapping[c] = canonical
    df = df.rename(columns=mapping)
    for c in ["open", "high", "low", "close"]:
        if c not in df:
            raise ValueError(f"Missing required column: {c}")
    if "volume" not in df:
        df["volume"] = 0.0

    ts = pd.to_datetime(df[tcol], errors="coerce")
    good = ts.notna()
    df = df.loc[good].copy()
    ts = ts.loc[good]
    if getattr(ts.dt, "tz", None) is None:
        ts = ts.dt.tz_localize(source_tz, ambiguous="infer", nonexistent="shift_forward")
    else:
        ts = ts.dt.tz_convert(source_tz)
    df.index = pd.DatetimeIndex(ts).tz_convert(ET)
    for c in ["open", "high", "low", "close", "volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["open", "high", "low", "close"]).sort_index()
    df = df[~df.index.duplicated(keep="last")]

    if input_minutes is None:
        if len(df) > 2:
            d = df.index.to_series().diff().dropna().dt.total_seconds() / 60
            mode = d[(d > 0) & (d <= 60)].round().mode()
            input_minutes = int(mode.iloc[0]) if len(mode) else 5
        else:
            input_minutes = 5

    if input_minutes <= 1:
        # Label bars by START time. A 5m candle beginning at 09:30 is known at 09:35.
        df = df.resample("5min", label="left", closed="left").agg(
            open=("open", "first"), high=("high", "max"), low=("low", "min"),
            close=("close", "last"), volume=("volume", "sum")
        ).dropna(subset=["open", "high", "low", "close"])
    elif input_minutes != 5:
        raise ValueError(f"Input inferred as {input_minutes}m; supply 1m or 5m bars")

    # Bar-start index, plus explicit completed time for causal decisions.
    df["bar_start"] = df.index
    df["bar_end"] = df.index + pd.Timedelta(minutes=5)
    return df


def true_range(df: pd.DataFrame) -> pd.Series:
    prev = df.close.shift(1)
    return pd.concat([(df.high-df.low), (df.high-prev).abs(), (df.low-prev).abs()], axis=1).max(axis=1)


def add_features(df5: pd.DataFrame, cfg: Config) -> tuple[pd.DataFrame, pd.DataFrame]:
    x = df5.copy()
    x["tr"] = true_range(x)
    x["atr"] = x.tr.rolling(cfg.atr_period, min_periods=cfg.atr_period).mean()
    x["body"] = (x.close-x.open).abs()
    x["range"] = (x.high-x.low).replace(0, np.nan)
    x["close_loc"] = ((x.close-x.low)/x.range).clip(0, 1).fillna(.5)
    x["body_ratio"] = (x.body/x.range).clip(0, 1).fillna(0)

    # 15m completed-bar series. Label RIGHT so a bar composed of 09:30,09:35,09:40
    # becomes available at 09:45, never at 09:30.
    df15 = x[["open","high","low","close","volume"]].resample(
        "15min", label="right", closed="left"
    ).agg(open=("open","first"), high=("high","max"), low=("low","min"),
          close=("close","last"), volume=("volume","sum")).dropna(subset=["open"])
    df15["tr"] = true_range(df15)
    df15["atr"] = df15.tr.rolling(cfg.atr_period, min_periods=cfg.atr_period).mean()
    df15["ema_fast"] = df15.close.ewm(span=cfg.trend_fast_15m, adjust=False).mean()
    df15["ema_slow"] = df15.close.ewm(span=cfg.trend_slow_15m, adjust=False).mean()
    df15["slow_slope"] = df15.ema_slow - df15.ema_slow.shift(cfg.trend_slope_lookback)

    # Map only already-COMPLETED 15m context to each 5m BAR END.
    ctx = df15[["ema_fast","ema_slow","slow_slope","atr"]].rename(columns={"atr":"atr15"})
    map_index = pd.DatetimeIndex(x.bar_end)
    mapped = ctx.reindex(map_index, method="ffill")
    mapped.index = x.index
    for c in mapped.columns:
        x[c] = mapped[c]

    return x, df15


def trading_session_date(ts: pd.Timestamp) -> pd.Timestamp.date:
    # CME equity session begins 18:00 ET on previous calendar evening.
    local = ts.tz_convert(ET)
    d = local.date()
    if local.hour >= 18:
        return (local + pd.Timedelta(days=1)).date()
    return d


def add_session_levels(x: pd.DataFrame) -> pd.DataFrame:
    y = x.copy()
    y["session_date"] = [trading_session_date(t) for t in y.index]
    y["on_high"] = np.nan; y["on_low"] = np.nan; y["on_mid"] = np.nan
    y["or_high"] = np.nan; y["or_low"] = np.nan

    for sd, g in y.groupby("session_date", sort=True):
        idx = g.index
        et_time = pd.Series(idx.time, index=idx)
        # Overnight: 18:00 previous evening to 09:29:59 ET.
        on_mask = [(t.hour >= 18 or t < pd.Timestamp("09:30").time()) for t in idx.time]
        on = g.loc[on_mask]
        if len(on):
            oh, ol = float(on.high.max()), float(on.low.min())
            y.loc[idx, "on_high"] = oh
            y.loc[idx, "on_low"] = ol
            y.loc[idx, "on_mid"] = (oh+ol)/2
        # 30m opening range, informational only for trend context.
        orm = g.between_time("09:30", "09:59")
        if len(orm):
            y.loc[idx, "or_high"] = float(orm.high.max())
            y.loc[idx, "or_low"] = float(orm.low.min())
    return y


def detect_zones(bars: pd.DataFrame, timeframe: str, cfg: Config) -> list[Zone]:
    """Create 3-bar FVGs causally and assign permanent death times.

    Bar timestamps in 5m data are START times. For 5m, zone born_time is third
    bar start + 5m. For 15m data labels already represent COMPLETION times.
    """
    z: list[Zone] = []
    highs = bars.high.to_numpy(float); lows = bars.low.to_numpy(float)
    closes = bars.close.to_numpy(float)
    atr = bars.atr.to_numpy(float) if "atr" in bars else np.full(len(bars), np.nan)
    times = bars.index
    step = pd.Timedelta(minutes=5 if timeframe == "5m" else 0)
    zid = 0
    for i in range(2, len(bars)):
        if not np.isfinite(atr[i]):
            continue
        min_gap = max(cfg.fvg_min_points, cfg.fvg_min_atr * atr[i])
        # Bull FVG: current low is above high two bars ago.
        gap = lows[i] - highs[i-2]
        if gap >= min_gap:
            born = times[i] + step
            z.append(Zone(zid, timeframe, +1, born, highs[i-2], lows[i],
                          (highs[i-2]+lows[i])/2, i)); zid += 1
        # Bear FVG: current high is below low two bars ago.
        gap = lows[i-2] - highs[i]
        if gap >= min_gap:
            born = times[i] + step
            z.append(Zone(zid, timeframe, -1, born, highs[i], lows[i-2],
                          (highs[i]+lows[i-2])/2, i)); zid += 1

    # Permanent lifecycle. Death is determined only using bars at/after born_time.
    # For 5m, evaluate each completed bar close beginning with first bar whose END
    # is after birth. For 15m, index itself is completion time.
    eval_times = bars.index + (pd.Timedelta(minutes=5) if timeframe == "5m" else pd.Timedelta(0))
    for zone in z:
        start = int(np.searchsorted(eval_times.asi8, zone.born_time.value, side="left"))
        max_age = cfg.fvg_max_age_bars_5m if timeframe == "5m" else max(8, cfg.fvg_max_age_bars_5m//3)
        end = min(len(bars), start + max_age)
        for j in range(start, end):
            c = closes[j]
            threshold = zone.midpoint if cfg.fvg_invalidate_at_midpoint else (zone.lower if zone.direction > 0 else zone.upper)
            invalid = c < threshold if zone.direction > 0 else c > threshold
            if invalid:
                zone.dead_time = eval_times[j]
                zone.death_reason = "close_invalidation"
                break
        if zone.dead_time is None and end < len(bars):
            zone.dead_time = eval_times[end]
            zone.death_reason = "expiry"
    return z


def build_zone_lookup(zones: list[Zone]) -> dict[int, Zone]:
    return {z.zid: z for z in zones}


def _time_between(ts: pd.Timestamp, start: str, end: str) -> bool:
    t = ts.tz_convert(ET).time()
    s = pd.Timestamp(start).time(); e = pd.Timestamp(end).time()
    return s <= t <= e


def complete_session_dates(x: pd.DataFrame, cfg: Config) -> list[object]:
    """Count only sessions with usable entry-window and EOD coverage.

    This prevents a partial file head/tail from diluting trades-per-session metrics.
    It does not alter candidate generation or P&L.
    """
    out = []
    for sd, g in x.groupby("session_date", sort=True):
        ends = list(g.bar_end)
        has_entry = any(_time_between(t, cfg.entry_start_et, cfg.entry_end_et) for t in ends)
        has_eod = any(t.tz_convert(ET).time() >= pd.Timestamp(cfg.eod_exit_et).time() for t in ends)
        has_levels = bool(np.isfinite(g.on_high).any() and np.isfinite(g.on_low).any())
        if has_entry and has_eod and has_levels:
            out.append(sd)
    return out


def generate_candidates(x: pd.DataFrame, zones5: list[Zone], cfg: Config) -> list[Candidate]:
    """Generate confirmed retest/rejection candidates from live zones.

    We intentionally do not use 15m FVG nesting in V1 because it collapses volume.
    15m EMA state is used only by TREND_FVG_CONTINUATION.
    """
    # Index zones by birth interval to avoid scanning every historical zone per bar.
    active: list[Zone] = []
    by_birth = sorted(zones5, key=lambda z: z.born_time)
    ptr = 0
    candidates: list[Candidate] = []
    last_sweep: dict[tuple[object,int], pd.Timestamp] = {}

    rows = list(x.itertuples())
    for i, r in enumerate(rows):
        decision_time = r.bar_end
        while ptr < len(by_birth) and by_birth[ptr].born_time <= decision_time:
            active.append(by_birth[ptr]); ptr += 1
        active = [z for z in active if z.alive_at(decision_time)]
        if not np.isfinite(r.atr):
            continue
        sd = r.session_date
        if not np.isfinite(r.on_low) or not np.isfinite(r.on_high):
            continue

        # Track RTH sweep/reclaim events beginning at 09:30 ET, once the overnight
        # high/low is final. Entry decisions still remain gated by entry_start/end.
        et_time = decision_time.tz_convert(ET).time()
        if et_time >= pd.Timestamp("09:30").time():
            if r.low < r.on_low and r.close >= r.on_low + cfg.sweep_reclaim_atr*r.atr:
                last_sweep[(sd,+1)] = decision_time
            if r.high > r.on_high and r.close <= r.on_high - cfg.sweep_reclaim_atr*r.atr:
                last_sweep[(sd,-1)] = decision_time

        if not _time_between(decision_time, cfg.entry_start_et, cfg.entry_end_et):
            continue

        for z in active:
            # Zone may not be traded on the bar that made it; born_time enforces this.
            if decision_time <= z.born_time:
                continue
            # Current completed bar must touch zone and reject in its direction.
            touched = r.low <= z.upper and r.high >= z.lower
            if not touched:
                continue
            if z.direction > 0:
                rejected = r.close > z.upper and r.close > r.open and r.close_loc >= 0.60
            else:
                rejected = r.close < z.lower and r.close < r.open and r.close_loc <= 0.40
            if not rejected:
                continue

            # Family 1: recent overnight sweep in SAME intended reversal direction.
            sw = last_sweep.get((sd, z.direction))
            if sw is not None:
                bars_since = int((decision_time - sw) / pd.Timedelta(minutes=5))
                if 0 <= bars_since <= cfg.sweep_lookback_bars:
                    candidates.append(Candidate(
                        "SWEEP_FVG_REVERSAL", z.direction, decision_time, z.zid,
                        z.lower, z.upper, float(r.atr), f"sweep_bars_since={bars_since}"
                    ))
                    continue

            # Family 2: 15m trend alignment. V2 intentionally removes the V1
            # premium/discount gate after diagnostics showed it eliminated every
            # trend-aligned rejection in the first real MNQ sessions.
            trend_up = np.isfinite(r.ema_fast) and r.ema_fast > r.ema_slow and r.slow_slope > 0
            trend_dn = np.isfinite(r.ema_fast) and r.ema_fast < r.ema_slow and r.slow_slope < 0
            if ((z.direction > 0 and trend_up) or (z.direction < 0 and trend_dn)):
                candidates.append(Candidate(
                    "TREND_FVG_CONTINUATION", z.direction, decision_time, z.zid,
                    z.lower, z.upper, float(r.atr),
                    f"ema15={r.ema_fast:.2f}/{r.ema_slow:.2f};slope={r.slow_slope:.2f}"
                ))
    return candidates


def _costs(cfg: Config, qty: int = 1) -> float:
    slip = cfg.slippage_ticks_each_side * 2 * MNQ_TICK_VALUE
    return qty * (cfg.commission_roundturn + slip)


def run_sequential(x: pd.DataFrame, candidates: list[Candidate], cfg: Config) -> pd.DataFrame:
    if not candidates:
        return pd.DataFrame(columns=[f.name for f in Trade.__dataclass_fields__.values()])
    rows = list(x.itertuples())
    start_times = np.array([r.bar_start.value for r in rows], dtype=np.int64)
    cand = sorted(candidates, key=lambda c: c.signal_time)
    trades: list[Trade] = []
    next_free = pd.Timestamp("1900-01-01", tz=ET)
    daily_r: dict[object,float] = {}
    daily_n: dict[object,int] = {}

    for c in cand:
        sd = trading_session_date(c.signal_time)
        if daily_n.get(sd, 0) >= cfg.max_trades_per_day or daily_r.get(sd,0) <= -cfg.daily_stop_r:
            continue
        if c.signal_time < next_free:
            continue
        # Entry bar START must be >= signal_time; signal_time is prior bar END.
        k = int(np.searchsorted(start_times, c.signal_time.value, side="left"))
        if k >= len(rows):
            continue
        er = rows[k]
        if trading_session_date(er.bar_start) != sd:
            continue
        entry = float(er.open)
        atr = c.atr
        buffer = cfg.zone_buffer_atr * atr
        if c.direction > 0:
            stop = c.zone_lower - buffer
            risk = entry - stop
        else:
            stop = c.zone_upper + buffer
            risk = stop - entry
        minrisk = cfg.min_stop_atr * atr; maxrisk = cfg.max_stop_atr * atr
        if not np.isfinite(risk) or risk <= 0 or risk < minrisk or risk > maxrisk:
            continue
        target_r = cfg.sweep_target_r if c.family == "SWEEP_FVG_REVERSAL" else cfg.trend_target_r
        target = entry + c.direction * target_r * risk

        exit_price = None; exit_time = None; reason = None
        eod = pd.Timestamp(cfg.eod_exit_et).time()
        for j in range(k, len(rows)):
            r = rows[j]
            if trading_session_date(r.bar_start) != sd:
                exit_price = float(rows[j-1].close) if j > k else entry
                exit_time = rows[j-1].bar_end if j > k else er.bar_end
                reason = "session_boundary"; break
            if r.bar_start.tz_convert(ET).time() >= eod:
                exit_price = float(r.open); exit_time = r.bar_start; reason = "eod"; break
            h, l = float(r.high), float(r.low)
            # Stop FIRST when both are touched: conservative with 5m path ambiguity.
            if c.direction > 0:
                if l <= stop:
                    exit_price = stop; exit_time = r.bar_end; reason = "stop"; break
                if h >= target:
                    exit_price = target; exit_time = r.bar_end; reason = "target"; break
            else:
                if h >= stop:
                    exit_price = stop; exit_time = r.bar_end; reason = "stop"; break
                if l <= target:
                    exit_price = target; exit_time = r.bar_end; reason = "target"; break
        if exit_price is None:
            exit_price = float(rows[-1].close); exit_time = rows[-1].bar_end; reason = "data_end"

        gross_pts = c.direction * (exit_price-entry)
        gross = gross_pts * MNQ_POINT_VALUE
        cost1 = _costs(cfg,1)
        net = gross-cost1
        risk_dollars_before_cost = risk*MNQ_POINT_VALUE
        net_r = net/max(risk_dollars_before_cost + cost1, 1e-9)
        per_contract_risk = risk_dollars_before_cost + cost1
        qty = min(cfg.max_mnq_contracts, max(1, int(cfg.risk_budget_dollars // per_contract_risk)))
        net_budget = gross*qty - _costs(cfg,qty)

        trades.append(Trade(
            family=c.family, direction="LONG" if c.direction>0 else "SHORT",
            signal_time=c.signal_time, entry_time=er.bar_start, exit_time=exit_time,
            entry=entry, stop=stop, target=target, exit_price=float(exit_price),
            exit_reason=reason, risk_points=risk, gross_points=gross_pts,
            gross_dollars_1mnq=gross, costs_1mnq=cost1, net_dollars_1mnq=net,
            net_r=net_r, quantity_risk_budget=qty, net_dollars_risk_budget=net_budget,
            session_date=str(sd), zone_id=c.zone_id, context=c.context
        ))
        daily_n[sd] = daily_n.get(sd,0)+1
        daily_r[sd] = daily_r.get(sd,0)+net_r
        next_free = exit_time

    return pd.DataFrame([asdict(t) for t in trades])


def metrics(t: pd.DataFrame, sessions: int | None = None) -> dict:
    if t.empty:
        return {"trades":0,"win_rate":0.0,"net_1mnq":0.0,"profit_factor":0.0,
                "max_drawdown_1mnq":0.0,"avg_r":0.0,"trades_per_session":0.0}
    pnl = t.net_dollars_1mnq.astype(float)
    wins = pnl[pnl>0].sum(); losses = -pnl[pnl<0].sum()
    # Anchor the equity curve at starting equity (0). Without this, an
    # immediate losing trade incorrectly reports zero drawdown because the
    # first negative cumulative PnL becomes the running peak.
    eq = pd.concat([pd.Series([0.0]), pnl.reset_index(drop=True).cumsum()], ignore_index=True)
    dd = eq.cummax() - eq
    sessions = sessions if sessions is not None else t.session_date.nunique()
    return {
        "trades":int(len(t)),
        "win_rate":float((pnl>0).mean()*100),
        "net_1mnq":float(pnl.sum()),
        "profit_factor":float(wins/losses) if losses>0 else float("inf"),
        "max_drawdown_1mnq":float(dd.max()),
        "avg_r":float(t.net_r.mean()),
        "total_r":float(t.net_r.sum()),
        "trades_per_session":float(len(t)/sessions) if sessions else 0.0,
        "long_trades":int((t.direction=="LONG").sum()),
        "short_trades":int((t.direction=="SHORT").sum()),
        "risk_budget_net":float(t.net_dollars_risk_budget.sum()),
    }


def report_by_year(t: pd.DataFrame, all_session_dates: Iterable[object]) -> list[dict]:
    sess = pd.Series(list(all_session_dates), dtype="object")
    years = sorted({d.year for d in sess if hasattr(d,"year")})
    out=[]
    et = pd.to_datetime(t.entry_time, utc=True).dt.tz_convert(ET) if not t.empty else pd.Series(dtype="datetime64[ns]")
    for y in years:
        sub = t.loc[et.dt.year==y].copy() if not t.empty else t.copy()
        days = sum(1 for d in sess if d.year==y)
        out.append({"year":y, **metrics(sub,days)})
    return out


def audit_invariants(x: pd.DataFrame, zones: list[Zone], candidates: list[Candidate], trades: pd.DataFrame) -> dict:
    errors=[]
    for z in zones:
        if z.dead_time is not None and z.dead_time < z.born_time:
            errors.append(f"zone {z.zid} dies before birth")
    # Candidate must reference an alive zone at its signal time.
    lookup=build_zone_lookup(zones)
    for c in candidates:
        z=lookup[c.zone_id]
        if not z.alive_at(c.signal_time):
            errors.append(f"candidate uses dead/unborn zone {c.zone_id}")
    if not trades.empty:
        tt=trades.sort_values("entry_time").reset_index(drop=True)
        ent=pd.to_datetime(tt.entry_time,utc=True).to_numpy()
        ex=pd.to_datetime(tt.exit_time,utc=True).to_numpy()
        if len(tt)>1 and not (ent[1:]>=ex[:-1]).all(): errors.append("overlapping positions")
        sig=pd.to_datetime(tt.signal_time,utc=True).to_numpy()
        if not (ent>=sig).all(): errors.append("entry before signal")
        if not (pd.to_numeric(tt.risk_points)>0).all(): errors.append("nonpositive risk")
    return {"passed":not errors,"errors":errors,"zones":len(zones),"candidates":len(candidates),"trades":len(trades)}


def synthetic_self_test() -> dict:
    """Targeted invariants, independent of market profitability."""
    cfg=Config(fvg_min_points=.5, fvg_min_atr=0.0, atr_period=3, fvg_max_age_bars_5m=20)
    idx=pd.date_range("2026-01-05 09:30",periods=12,freq="5min",tz=ET)
    # Make a clear bull FVG on third bar: low[2] > high[0]. Then invalidate later.
    d=pd.DataFrame({
        "open":[100,101,104,105,104.5,103,101.5,100.5,101,102,103,104],
        "high":[101,103,106,106,105,104,102,101,102,103,104,105],
        "low" :[99,100.5,103,104,103,102,100.5,99.5,100,101,102,103],
        "close":[100.5,102.5,105.5,104.5,103.5,102.5,101,100,101.5,102.5,103.5,104.5],
        "volume":100,
    },index=idx)
    d["bar_start"]=d.index; d["bar_end"]=d.index+pd.Timedelta(minutes=5)
    d["atr"]=true_range(d).rolling(3,min_periods=3).mean()
    zones=detect_zones(d,"5m",cfg)
    bull=[z for z in zones if z.direction>0]
    assert bull, "synthetic FVG not detected"
    z=bull[0]
    assert z.born_time==idx[2]+pd.Timedelta(minutes=5), "FVG known too early"
    if z.dead_time is not None:
        assert not z.alive_at(z.dead_time), "dead zone resurrected at death time"
        assert not z.alive_at(z.dead_time+pd.Timedelta(hours=1)), "dead zone resurrected later"

    # Stop-first ambiguity check through a minimal direct calculation.
    entry=100.; stop=99.; target=102.; h=103.; l=98.
    result="stop" if l<=stop else ("target" if h>=target else "none")
    assert result=="stop"
    return {"passed":True,"bull_zone_born":str(z.born_time),"bull_zone_dead":str(z.dead_time),"stop_first":True}


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("csv",type=Path)
    ap.add_argument("--source-tz",default="America/New_York")
    ap.add_argument("--input-minutes",type=int,choices=[1,5],default=None)
    ap.add_argument("--out",type=Path,default=Path("MNQ_V1_RESULTS"))
    ap.add_argument("--self-test",action="store_true")
    args=ap.parse_args()
    if args.self_test:
        print(json.dumps(synthetic_self_test(),indent=2)); return 0

    cfg=Config(); args.out.mkdir(parents=True,exist_ok=True)
    x=load_bars(args.csv,args.source_tz,args.input_minutes)
    x,df15=add_features(x,cfg); x=add_session_levels(x)
    zones5=detect_zones(x,"5m",cfg)
    # 15m zones are built for audit/context research and saved; V1 signal families do
    # not require nesting because we want to measure its contribution separately later.
    zones15=detect_zones(df15,"15m",cfg)
    candidates=generate_candidates(x,zones5,cfg)
    trades=run_sequential(x,candidates,cfg)
    all_dates=complete_session_dates(x,cfg)
    yearly=report_by_year(trades,all_dates)
    inv=audit_invariants(x,zones5,candidates,trades)
    report={
        "engine":"SOVEREIGN_MNQ_V2_NO_PD_RESEARCH",
        "orders_enabled":False,
        "config":asdict(cfg),
        "data":{"file":str(args.csv),"bars_5m":len(x),"first":str(x.index.min()),"last":str(x.index.max()),"sessions":len(all_dates)},
        "overall":metrics(trades,len(all_dates)),
        "by_year":yearly,
        "by_family":{f:metrics(g,g.session_date.nunique()) for f,g in trades.groupby("family")} if not trades.empty else {},
        "by_direction":{f:metrics(g,g.session_date.nunique()) for f,g in trades.groupby("direction")} if not trades.empty else {},
        "audit":inv,
        "disclosure":"Historical research only. No claim of future profitability. 5m OHLC cannot resolve intrabar order beyond the conservative stop-first rule. Parameters are fixed defaults, not a promise of optimality."
    }
    trades.to_csv(args.out/"trades.csv",index=False)
    pd.DataFrame(yearly).to_csv(args.out/"annual_summary.csv",index=False)
    pd.DataFrame([asdict(z) for z in zones5]).to_csv(args.out/"zones_5m.csv",index=False)
    pd.DataFrame([asdict(z) for z in zones15]).to_csv(args.out/"zones_15m.csv",index=False)
    pd.DataFrame([asdict(c) for c in candidates]).to_csv(args.out/"candidates.csv",index=False)
    (args.out/"report.json").write_text(json.dumps(report,indent=2,default=str))
    (args.out/"config.json").write_text(json.dumps(asdict(cfg),indent=2))
    print(json.dumps(report,indent=2,default=str))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
